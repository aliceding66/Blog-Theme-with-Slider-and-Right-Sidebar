<?php

$themename = $dname.'Theme';
$options = array(
    "d_description", "d_keywords", "d_tui", "d_sticky_b", "d_sticky_count", "d_linkpage_cat", "d_tougao_b", "d_tougao_time", "d_tougao_mailto", "d_avatar_b", "d_avatarDate", "d_sideroll_b", "d_sideroll_1", "d_sideroll_2", "d_pingback_b", "d_autosave_b", "d_tqq_b", "d_tqq", "d_weibo_b", "d_weibo", "d_facebook_b", "d_facebook", "d_twitter_b", "d_twitter", "d_rss","d_qqContact_b","d_qqContact","d_weixin_b","d_weixin","d_emailContact_b","d_emailContact", "d_track_b", "d_track", "d_headcode_b", "d_headcode", "d_footcode_b", "d_footcode", "d_adsite_01_b", "d_adsite_01", "d_adindex_02_b", "d_adindex_02", "d_adindex_01_b", "d_adindex_01", "d_adindex_03_b", "d_adindex_03", "d_adpost_01_b", "d_adpost_01", "d_adpost_02_b", "d_adpost_02", "d_adpost_03_b", "d_adpost_03", "d_sign_b", "d_jquerybom_b", "d_ajaxpager_b", "d_thumbnail_b", "d_bdshare_b", "d_related_count", "d_post_views_b", "d_post_author_b", "d_post_comment_b", "d_post_time_b","hot_list_title","hot_list_number","hot_list_date","hot_list_check","d_post_like_b","d_singleMenu_b","Mobiled_adindex_02_b","Mobiled_adindex_02","Mobiled_adpost_01_b","Mobiled_adpost_01","Mobiled_adpost_02_b","Mobiled_adpost_02","d_spamComments_b"
);

function mytheme_add_admin() {
    global $themename, $options;
    if ( $_GET['page'] == basename(__FILE__) ) {
        if ( 'save' == $_REQUEST['action'] ) {
            foreach ($options as $value) {
                update_option( $value, $_REQUEST[ $value ] ); 
            }
            header("Location: admin.php?page=alice.php&saved=true");
            die;
        }
    }
    add_theme_page($themename." Options", $themename."Setting", 'edit_themes', basename(__FILE__), 'mytheme_admin');
}

function mytheme_admin() {
    global $themename, $options;
    $i=0;
    if ( $_REQUEST['saved'] ) echo '<div class="updated settings-error"><p>'.$themename.'Setting updated</p></div>';
?>

<div class="wrap d_wrap">
    <link rel="stylesheet" href="<?php echo esc_url(get_template_directory_uri()) ?>/admin/admin.css"/>
    <h2><?php echo $themename; ?>Setting
        <span class="d_themedesc">Theme Author:<a href="http://cn.aliceding.com/" target="_blank">Alice Ding</a> &nbsp;&nbsp; <a href="http://cn.aliceding.com" target="_blank">Visit<?php echo $themename; ?>Homepage</a></span><span style="font-size:16px;color: rgb(245, 99, 99);padding-left:20px;">Support Alice by -><a href="http://cn.aliceding.com" target="_blank">Donation</a></span>
    </h2>

<form method="post" class="d_formwrap">
    <table>
    <thead>
        <tr>
            <th width="200"></th>
            <th></th>
        </tr>
    </thead>

    <tr>
        <td class="d_tit">Hompage Slider</td>
        <td>
            <label class="checkbox inline">
                <input type="checkbox" id="d_sticky_b" name="d_sticky_b" <?php if(dopt('d_sticky_b')) echo 'checked="checked"' ?>>Activate
            </label>
            Slider Number: <input class="d_num" name="d_sticky_count" id="d_sticky_count" type="number" value="<?php echo dopt('d_sticky_count'); ?>">(The default is 4)
            &nbsp; &nbsp;
            <span class="d_tip">Please ensure you have more than 4 articles before activation and the post featured image is 716*297 pixels.  </span>
        </td>
    </tr>

    <tr>
        <td class="d_tit">Do not display default featured images if the post has no featured image</td>
        <td>
            <label class="checkbox inline">
                <input type="checkbox" id="d_thumbnail_b" name="d_thumbnail_b" <?php if(dopt('d_thumbnail_b')) echo 'checked="checked"' ?>>Activate
            </label>
      Ajax list loading paginating content
            <label class="checkbox inline">
                <input type="checkbox" id="d_ajaxpager_b" name="d_ajaxpager_b" <?php if(dopt('d_ajaxpager_b')) echo 'checked="checked"' ?>>Activate
            </label>
		Article Breadcumb navigation at the top of the post <label class="checkbox inline">
                <input type="checkbox" id="d_singleMenu_b" name="d_singleMenu_b" <?php if(dopt('d_singleMenu_b')) echo 'checked="checked"' ?>>Activate
            </label>
        </td>
    </tr>
 <tr>
      <td class="d_tit">Popular Ranking</td>
        <td>
            <label class="checkbox inline">
                <input type="checkbox" id="hot_list_check" name="hot_list_check" <?php if(dopt('hot_list_check')) echo 'checked="checked"' ?>>Activate
            </label>
        Display date <input class="hot_list_date" name="hot_list_date" id="hot_list_date" type="number" value="<?php echo dopt('hot_list_date'); ?>"> 
        	(the default is 7)
	
	Display list <input class="hot_list_number" name="hot_list_number" id="hot_list_number" type="number" value="<?php echo dopt('hot_list_number'); ?>">(The default is 10)

	&nbsp;&nbsp; Title<input class="d_inp_short" name="hot_list_title" id="hot_list_title" type="text" value="<?php echo dopt('hot_list_title'); ?>">
	</td>
    </tr>
    <tr>
        <td class="d_tit">Post List Setting </td>
        <td>
            <label class="checkbox inline">
                <input type="checkbox" id="d_post_views_b" name="d_post_views_b" <?php if(dopt('d_post_views_b')) echo 'checked="checked"' ?>>No display for total visitor number.
            </label> &nbsp; &nbsp; 
            <label class="checkbox inline">
                <input type="checkbox" id="d_post_author_b" name="d_post_author_b" <?php if(dopt('d_post_author_b')) echo 'checked="checked"' ?>>No display for author name
            </label> &nbsp; &nbsp; 
            <label class="checkbox inline">
                <input type="checkbox" id="d_post_comment_b" name="d_post_comment_b" <?php if(dopt('d_post_comment_b')) echo 'checked="checked"' ?>>No display for totla comment number
            </label> &nbsp; &nbsp; 
            <label class="checkbox inline">
                <input type="checkbox" id="d_post_time_b" name="d_post_time_b" <?php if(dopt('d_post_time_b')) echo 'checked="checked"' ?>>No post time display
            </label> &nbsp; &nbsp; 
  	<label class="checkbox inline">
                <input type="checkbox" id="d_post_like_b" name="d_post_like_b" <?php if(dopt('d_post_like_b')) echo 'checked="checked"' ?>>No likes display
            </label>
        </td>
    </tr>
        </td>
    </tr>
    <tr>
        <td class="d_tit">Post Page Setting</td>
        <td>
            Display posts number: <input class="d_num" name="d_related_count" id="d_related_count" type="number" value="<?php echo dopt('d_related_count'); ?>"> (The default is 8)
        </td>
    </tr>
    <tr>
        <td class="d_tit">jQuery Setting</td>
        <td>
            <label class="checkbox inline">
                <input type="checkbox" id="d_jquerybom_b" name="d_jquerybom_b" <?php if(dopt('d_jquerybom_b')) echo 'checked="checked"' ?>>Activate
            </label>
            <span class="d_tip"></span>
        </td>
    </tr>
    <tr>
        <td class="d_tit">Instagram</td>
        <td>
            <label class="checkbox inline">
                <input type="checkbox" id="d_inst_b" name="d_inst_b" <?php if(dopt('d_inst_b')) echo 'checked="checked"' ?>>Activate
            </label>
            URL:<input class="d_inp_short" name="d_inst" id="d_inst" type="text" value="<?php echo dopt('d_inst'); ?>">
        </td>
    </tr>
    <tr>
        <td class="d_tit">Youtube</td>
        <td>
            <label class="checkbox inline">
                <input type="checkbox" id="d_you_b" name="d_you_b" <?php if(dopt('d_you_b')) echo 'checked="checked"' ?>>Activate
            </label>
            URL:<input class="d_inp_short" name="d_you" id="d_you" type="text" value="<?php echo dopt('d_you'); ?>">
        </td>
    </tr>
   <tr>
        <td class="d_tit">Linkedin</td>
        <td>
            <label class="checkbox inline">
                <input type="checkbox" id="d_lin_b" name="d_lin_b" <?php if(dopt('d_lin_b')) echo 'checked="checked"' ?>>Activate
            </label>
            URL:<input class="d_inp_short" name="d_lin" id="d_lin" type="text" value="<?php echo dopt('d_lin'); ?>">
        </td>
    </tr>
   <tr>
        <td class="d_tit">Google+</td>
        <td>
            <label class="checkbox inline">
                <input type="checkbox" id="d_goo_b" name="d_goo_b" <?php if(dopt('d_goo_b')) echo 'checked="checked"' ?>>Activate
            </label>
            URL: <input class="d_inp_short" name="d_goo" id="d_goo" type="text" value="<?php echo dopt('d_goo'); ?>">
        </td>
    </tr>
   <tr>
        <td class="d_tit">Email</td>
        <td>
            <label class="checkbox inline">
                <input type="checkbox" id="d_emailContact_b" name="d_emailContact_b" <?php if(dopt('d_emailContact_b')) echo 'checked="checked"' ?>>Activate
            </label>
            URL: <input class="d_inp_short" name="d_emailContact" id="d_emailContact" type="text" value="<?php echo dopt('d_emailContact'); ?>">
        </td>
    </tr>
    <tr>
        <td class="d_tit">Facebook</td>
        <td>
            <label class="checkbox inline">
               <input type="checkbox" id="d_facebook_b" name="d_facebook_b" <?php if(dopt('d_facebook_b')) echo 'checked="checked"' ?>>Activate
            </label>
            URL: <input class="d_inp_short" name="d_facebook" id="d_facebook" type="text" value="<?php echo dopt('d_facebook'); ?>">
        </td>
    </tr>
    <tr>
        <td class="d_tit">Twitter</td>
        <td>
            <label class="checkbox inline">
                <input type="checkbox" id="d_twitter_b" name="d_twitter_b" <?php if(dopt('d_twitter_b')) echo 'checked="checked"' ?>>Activate
            </label>
            URL: <input class="d_inp_short" name="d_twitter" id="d_twitter" type="text" value="<?php echo dopt('d_twitter'); ?>">
        </td>
    </tr>
    <tr>
        <td class="d_tit">RSS</td>
        <td>
            <input class="d_inp_short" name="d_rss" id="d_rss" type="text" value="<?php echo dopt('d_rss'); ?>">
            <span class="d_tip">It could be any website url beside this website. </span>
        </td>
    </tr>
    <tr>
        <td class="d_tit">Search Engine Analytic Scripts</td>
        <td>
            <label class="checkbox inline">
                <input type="checkbox" id="d_track_b" name="d_track_b" <?php if(dopt('d_track_b')) echo 'checked="checked"' ?>>Activate
  <span class="d_tip">Google Analytics, Baidu Analytics, etc.</span>
            </label>
            <textarea name="d_track" id="d_track" type="textarea" rows="2"><?php echo dopt('d_track'); ?></textarea>
          
        </td>
    </tr>
    <tr>
        <td class="d_tit">Page Header Script</td>
        <td>
            <label class="checkbox inline">
                <input type="checkbox" id="d_headcode_b" name="d_headcode_b" <?php if(dopt('d_headcode_b')) echo 'checked="checked"' ?>>Activate
<span class="d_tip">Head Section</span>
            </label>
            <textarea name="d_headcode" id="d_headcode" type="textarea" rows="2"><?php echo dopt('d_headcode'); ?></textarea>
            
        </td>
    </tr>
    <tr>
        <td class="d_tit">Page Footer Script</td>
        <td>
            <label class="checkbox inline">
                <input type="checkbox" id="d_footcode_b" name="d_footcode_b" <?php if(dopt('d_footcode_b')) echo 'checked="checked"' ?>>Activate
 <span class="d_tip">Footer Section</span>
            </label>
            <textarea name="d_footcode" id="d_footcode" type="textarea" rows="2"><?php echo dopt('d_footcode'); ?></textarea>
           
        </td>
    </tr>
    <tr>
        <td class="d_tit"></td>
        <td>
            <div class="d_desc">
                <input class="button-primary" name="save" type="submit" value="Save">
            </div>
            <input type="hidden" name="action" value="save">
        </td>
    </tr>

    </table>
</form>
</div>
<script>
var aaa = []
jQuery('.d_wrap input, .d_wrap textarea').each(function(e){
    if( jQuery(this).attr('id') ) aaa.push( jQuery(this).attr('id') )
})
console.log( aaa )
</script>
<?php } ?>
<?php add_action('admin_menu', 'mytheme_add_admin');?>