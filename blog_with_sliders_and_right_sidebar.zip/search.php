<?php get_header(); ?>
<div class="content-wrap">
	<div class="content">
		<?php if ( !have_posts() ) : ?>
			<header class="archive-header"> 
				<h1>There is nothing about <?php echo $s; ?>.</h1>
				<p class="muted">We recommand this:</p>
			</header>
			<?php 
				$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
				$args = array(
				    'showposts' => 4,
				    'caller_get_posts' => 1,
				    'paged' => $paged
				);
				query_posts($args);
			?>
			<?php include( 'modules/excerpt.php' ); ?>
		<?php else: ?>
			<header class="archive-header"> 
				<h1>There is something about <?php echo $s; ?>.</h1>
			</header>
			<?php include( 'modules/archive_title.php' ); ?>
		<?php endif; ?>
	</div>
</div>
<?php get_sidebar(); get_footer(); ?>