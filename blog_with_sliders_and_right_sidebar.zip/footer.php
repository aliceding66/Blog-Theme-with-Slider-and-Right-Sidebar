</section>
<footer class="footer">
    <div class="footer-inner">
        <div class="copyright pull-left">
         <a href="http://cn.aliceding.com/" title="Alice Ding's Blog">Alice Ding's Blog'</a> Copyright @ Alice Ding· <a href="http://cn.aliceding.com" title="moretheme">More Themes</a>   Using WordPress & <a rel="nofollow" target="_blank" href="http://www.bluehost.com/track/miappleteam/">Bluehost Hosting</a>
        </div>
        <div class="trackcode pull-right">
            <?php if( dopt('d_track_b') ) echo dopt('d_track'); ?>
        </div>
    </div>
</footer>

<?php 
wp_footer(); 
global $dHasShare; 
if($dHasShare == true){ 
	echo'<script>with(document)0[(getElementsByTagName("head")[0]||body).appendChild(createElement("script")).src="http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion="+~(-new Date()/36e5)];</script>';
}  
if( dopt('d_footcode_b') ) echo dopt('d_footcode'); 
?>
</body>
</html>