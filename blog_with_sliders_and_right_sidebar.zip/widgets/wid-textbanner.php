<?php  
add_action( 'widgets_init', 'd_textbanners' );

function d_textbanners() {
	register_widget( 'd_textbanner' );
}

class d_textbanner extends WP_Widget {
	function d_textbanner() {
		$widget_ops = array( 'classname' => 'd_textbanner', 'description' => 'show special recommand textarea' );
		$this->WP_Widget( 'd_textbanner', 'Special Recommand', $widget_ops, $control_ops );
	}

	function widget( $args, $instance ) {
		extract( $args );

		$title = apply_filters('widget_name', $instance['title']);
		$tag = $instance['tag'];
		$content = $instance['content'];
		$link = $instance['link'];
		$style = $instance['style'];
		$blank = $instance['blank'];

		$lank = '';
		if( $blank ) $lank = ' target="_blank"';

		echo $before_widget;
		echo '<a class="'.$style.'" href="'.$link.'"'.$lank.'>';
		echo '<div class="title"><h2>'.$tag.'</h2></div>';
		echo '<h3>'.$title.'</h3>';
		echo '<p>'.$content.'</p>';
		echo '</a>';
		echo $after_widget;
	}

	function form($instance) {
?>
		<p>
			<label>
				Name:
				<input id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" class="widefat" />
			</label>
		</p>
		<p>
			<label>
				Description:
				<textarea id="<?php echo $this->get_field_id('content'); ?>" name="<?php echo $this->get_field_name('content'); ?>" class="widefat" rows="3"><?php echo $instance['content']; ?></textarea>
			</label>
		</p>
		<p>
			<label>
				Tag:
				<input id="<?php echo $this->get_field_id('tag'); ?>" name="<?php echo $this->get_field_name('tag'); ?>" type="text" value="<?php echo $instance['tag']; ?>" class="widefat" />
			</label>
		</p>
		<p>
			<label>
				Link:
				<input style="width:100%;" id="<?php echo $this->get_field_id('link'); ?>" name="<?php echo $this->get_field_name('link'); ?>" type="url" value="<?php echo $instance['link']; ?>" size="24" />
			</label>
		</p>
		<p>
			<label>
				Style:
				<select style="width:100%;" id="<?php echo $this->get_field_id('style'); ?>" name="<?php echo $this->get_field_name('style'); ?>" style="width:100%;">
					<option value="style01" <?php selected('style01', $instance['style']); ?>>Blue</option>
					<option value="style02" <?php selected('style02', $instance['style']); ?>>Orange</option>
					<option value="style03" <?php selected('style03', $instance['style']); ?>>Green</option>
					<option value="style04" <?php selected('style04', $instance['style']); ?>>Purple</option>
					<option value="style05" <?php selected('style05', $instance['style']); ?>>Cyan</option>
				</select>
			</label>
		</p>
		<p>
			<label>
				<input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked( $instance['blank'], 'on' ); ?> id="<?php echo $this->get_field_id('blank'); ?>" name="<?php echo $this->get_field_name('blank'); ?>">Open in a new explorer window
			</label>
		</p>
<?php
	}
}

?>