<?php
add_action( 'widgets_init', 'd_postlists' );

function d_postlists() {
	register_widget( 'd_postlist' );
}

class d_postlist extends WP_Widget {
	function d_postlist() {
		$widget_ops = array( 'classname' => 'd_postlist', 'description' => 'Comments List(Latest Posts, Posts with the Most Comments, Random Posts)' );
		$this->WP_Widget( 'd_postlist', 'Alice - Article List', $widget_ops, $control_ops );
	}

	function widget( $args, $instance ) {
		extract( $args );

		$title        = apply_filters('widget_name', $instance['title']);
		$limit        = $instance['limit'];
		$cat          = $instance['cat'];
		$orderby      = $instance['orderby'];
		$more = $instance['more'];
		$link = $instance['link'];
		$img = $instance['img'];

		$mo='';
		$style='';
		if( $more!='' && $link!='' ) $mo='<a class="btn" href="'.$link.'">'.$more.'</a>';
		if( !$img ) $style = ' class="nopic"';
		echo $before_widget;
		echo $before_title.$mo.$title.$after_title; 
		echo '<ul'.$style.'>';
		echo dtheme_posts_list( $orderby,$limit,$cat,$img );
		echo '</ul>';
		echo $after_widget;
	}

	function form( $instance ) {
?>
		<p>
			<label>
				Title:
				<input style="width:100%;" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" />
			</label>
		</p>
		<p>
			<label>
				Sort:
				<select style="width:100%;" id="<?php echo $this->get_field_id('orderby'); ?>" name="<?php echo $this->get_field_name('orderby'); ?>" style="width:100%;">
					<option value="comment_count" <?php selected('comment_count', $instance['orderby']); ?>>Comments Count</option>
					<option value="date" <?php selected('date', $instance['orderby']); ?>>Post Time</option>
					<option value="rand" <?php selected('rand', $instance['orderby']); ?>>Random</option>
				</select>
			</label>
		</p>
		<p>
			<label>
				Sort Limitation Setting:
				<a style="font-weight:bold;color:#f60;text-decoration:none;" href="javascript:;" title="Format:1,2 &nbsp;Post Type ID=1,2&#13;Format: -1,-2 &nbsp;Post Type=1,2&#13;or just 1, -1;Please notice the comma must be
 in default English Version">?</a>
				<input style="width:100%;" id="<?php echo $this->get_field_id('cat'); ?>" name="<?php echo $this->get_field_name('cat'); ?>" type="text" value="<?php echo $instance['cat']; ?>" size="24" />
			</label>
		</p>
		<p>
			<label>
				Show quantity:
				<input style="width:100%;" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="number" value="<?php echo $instance['limit']; ?>" size="24" />
			</label>
		</p>
		<p>
			<label>
				More-Show text:
				<input style="width:100%;" id="<?php echo $this->get_field_id('more'); ?>" name="<?php echo $this->get_field_name('more'); ?>" type="text" value="<?php echo $instance['more']; ?>" size="24" />
			</label>
		</p>
		<p>
			<label>
				More-Link:
				<input style="width:100%;" id="<?php echo $this->get_field_id('link'); ?>" name="<?php echo $this->get_field_name('link'); ?>" type="url" value="<?php echo $instance['link']; ?>" size="24" />
			</label>
		</p>
		<p>
			<label>
				<input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked( $instance['img'], 'on' ); ?> id="<?php echo $this->get_field_id('img'); ?>" name="<?php echo $this->get_field_name('img'); ?>">Show images
			</label>
		</p>
		
	<?php
	}
}


function dtheme_posts_list($orderby,$limit,$cat,$img) {
	$args = array(
		'order'            => DESC,
		'cat'              => $cat,
		'orderby'          => $orderby,
		'showposts'        => $limit,
		'caller_get_posts' => 1
	);
	query_posts($args);
	while (have_posts()) : the_post(); 
?>
<li><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" ><?php if( $img ){echo '<span class="thumbnail">';echo '<img src="'.get_template_directory_uri().'/timthumb.php?src=';echo post_thumbnail_src();echo '&h=64&w=100&q=90&zc=1&ct=1" alt="'.get_the_title().'" /></span>'; }else{$img = '';} ?><span class="text"><?php the_title(); ?></span><span class="muted"><?php the_time('Y-m-d');?></span><span class="muted"><?php comments_number('', '1 Comments', '% Comments'); ?></span></a></li>
<?php
	
    endwhile; wp_reset_query();
}

?>